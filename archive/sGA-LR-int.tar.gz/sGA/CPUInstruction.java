abstract public class CPUInstruction
{
	abstract public void execute();
	abstract public String toString();
}

