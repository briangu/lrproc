final public class MyChromosome extends

// Put your Chromosome class name here (comment out the others):

   // BitCountChromosome
   // XtoTenthChromosome
   //   SinesChromosome
   // ByteCountChromosome
	HorseChromosome

   {public MyChromosome() {super();}
}

